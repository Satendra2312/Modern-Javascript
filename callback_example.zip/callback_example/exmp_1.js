//Example-1

/* //  program that shows the delay in execution
const greet = () => {
    console.log('Hello world');
}

const sayName = (name) => {
    console.log('Hello' + ' ' + name);
}

// calling the function
setTimeout(greet, 2000);
sayName('John'); */


//Example-2
const status = require('./public/hello.txt')
status.readFile('asynch.txt', (err, callback) => {
    if (err)
        return console.error(err);
    console.log(callback.toString());
});
console.log("Execution ends"); 
